#!/usr/bin/env python3

from MiniMIPS import MiniMIPS

miniMIPS = MiniMIPS(1024, 1024)

# instruction memory
miniMIPS.setInstMemory( 0, 4, '0001102a') # slt $2, $0, $1
miniMIPS.setInstMemory( 4, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory( 8, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(12, 4, '10400008') # beq $2, $0, 32
miniMIPS.setInstMemory(16, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(20, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(24, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(28, 4, '00230822') # sub $1, $1, $3
miniMIPS.setInstMemory(32, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(36, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(40, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(44, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(48, 4, '00230820') # add $1, $1, $3
miniMIPS.setInstMemory(52, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(56, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(60, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(64, 4, '00000020') # add $0, $0, $0

# registers
miniMIPS.setRegister(1, 'ffffff06') # $1 = 0xFFFFFF06
miniMIPS.setRegister(3, '000000ff') # $3 = 0x000000FF

# simulate 12 cycles
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.printRegister(2)
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.printPC()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.printRegister(1)

