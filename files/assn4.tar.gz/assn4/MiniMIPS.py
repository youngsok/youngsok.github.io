import bitarray, bitarray.util

class MiniMIPS:

  def __init__(self, dataMemSize, instMemSize):
    # 32 general-purpose registers ($0 ~ $31)
    self.registers = []
    for i in range(32):
      self.registers.append(bitarray.util.zeros(32))
    # byte-addressable data memory
    self.data_memory_size = dataMemSize
    self.data_memory = bytearray(self.data_memory_size)
    # byte-addressable instruction memory
    self.inst_memory_size = instMemSize
    self.inst_memory = bytearray(self.inst_memory_size)
    # $pc
    self.pc = bitarray.util.zeros(32)

  def setRegister(self, num, data):
    # num: register #, data: 32-bit hex string
    assert (num >= 0 and num < 32)
    self.registers[num] = bitarray.util.hex2ba(data)

  def printRegister(self, num):
    # num: register #
    assert (num >= 0 and num < 32)
    data = bitarray.util.ba2hex(self.registers[num])
    print("[printRegister] ${} = 0x{}".format(num, data))

  def printPC(self):
    print("[printPC] $pc = 0x{}".format(bitarray.util.ba2hex(self.pc)))

  def setDataMemory(self, addr, size, data):
    # addr: starting address, size: size in bytes, data: hex string
    assert (size > 0)
    assert (addr >= 0 and addr + size < self.data_memory_size)
    assert (len(data) == size * 2)
    self.data_memory[addr : (addr + size)] = bytearray.fromhex(data)

  def setInstMemory(self, addr, size, data):
    # addr: starting address, size: size in bytes, data: hex string
    assert (size > 0)
    assert (addr >= 0 and addr + size < self.inst_memory_size)
    assert (len(data) == size * 2)
    self.inst_memory[addr : (addr + size)] = bytearray.fromhex(data)

  def printDataMemory(self, addr, size):
    # addr: starting address, size: size in bytes
    assert (size > 0)
    assert (addr >= 0 and addr + size < self.data_memory_size)
    data = self.data_memory[addr : (addr + size)].hex()
    print("[printDataMemory] data_memory[{}:{}] = 0x{}".format(addr, addr + size, data))

  def printInstMemory(self, addr, size):
    # addr: starting address, size: size in bytes
    assert (size > 0)
    assert (addr >= 0 and addr + size < self.inst_memory_size)
    data = self.inst_memory[addr : (addr + size)].hex()
    print("[printInstMemory] inst_memory[{}:{}] = 0x{}".format(addr, addr + size, data))

  def advanceCycle(self):
    # FIXME
    print("[advanceCycle] $pc = 0x{}".format(bitarray.util.ba2hex(self.pc)))
    pass

if __name__ == "__main__":
  print("ERROR: 'MiniMIPS.py' should not be invoked directly!")

