#!/usr/bin/env python3

from MiniMIPS import MiniMIPS

miniMIPS = MiniMIPS(1024, 1024)

# instruction memory
miniMIPS.setInstMemory( 0, 4, '00a67020') # add $14, $5, $6
miniMIPS.setInstMemory( 4, 4, '8c2d0018') # lw $13, 24($1)
miniMIPS.setInstMemory( 8, 4, '00646020') # add $12, $3, $4
miniMIPS.setInstMemory(12, 4, '00435822') # sub $11, $2, $3
miniMIPS.setInstMemory(16, 4, '8c2a0014') # lw $10, 20($1)
miniMIPS.setInstMemory(20, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(24, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(28, 4, '00000020') # add $0, $0, $0
miniMIPS.setInstMemory(32, 4, '00000020') # add $0, $0, $0

# registers
miniMIPS.setRegister(1, '000000EC') # $1 = 0x0EC
miniMIPS.setRegister(2, '00000F00') # $2 = 0xF00
miniMIPS.setRegister(3, '00000100') # $3 = 0x100
miniMIPS.setRegister(4, '00000200') # $4 = 0x200
miniMIPS.setRegister(5, '00000300') # $5 = 0x300
miniMIPS.setRegister(6, '00000210') # $6 = 0x210

# data memory
miniMIPS.setDataMemory(256, 4, '01020304') # data[256:259] = 0x01020304
miniMIPS.setDataMemory(260, 4, '05060708') # data[260:263] = 0x05060708

# simulate 9 cycles
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle()
miniMIPS.advanceCycle() # $14 = $5 + $6 = 0x300 + 0x210 = 0x510
miniMIPS.printRegister(14)
miniMIPS.advanceCycle() # $13 = data[$1 + 24] = data[236 + 24] = data[260] = 0x05060708
miniMIPS.printRegister(13)
miniMIPS.advanceCycle() # $12 = $3 + $4 = 0x100 + 0x200 = 0x300
miniMIPS.printRegister(12)
miniMIPS.advanceCycle() # $11 = $2 - $3 = 0xF00 - 0x100 = 0xE00
miniMIPS.printRegister(11)
miniMIPS.advanceCycle() # $10 = data[$1 + 20] = data[236 + 20] = data[256] = 0x01020304
miniMIPS.printRegister(10)

